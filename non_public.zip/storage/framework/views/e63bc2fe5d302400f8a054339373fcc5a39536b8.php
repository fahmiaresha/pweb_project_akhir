
<?php $__env->startSection('title','Pesan Supplier'); ?>
<?php $__env->startSection('head'); ?>
  <!-- Datatable -->
  <link rel="stylesheet" href="<?php echo e(url('vendors/dataTable/datatables.min.css')); ?>" type="text/css">
 <!-- select2 -->
<link rel="stylesheet" href="../../vendors/select2/css/select2.min.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header d-md-flex justify-content-between">
        <div>
            <h3>Supplier</h3>
            <nav aria-label="breadcrumb" class="d-flex align-items-start">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Supplier</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Pesan Supplier</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
            <!-- modal -->
            <button type="button" class="btn btn-primary mb-3" data-toggle="modal"  data-target="#coba">
            <i class="fa fa-plus-circle mr-2"></i> Pesan Supplier</button>
            <div class="modal fade" tabindex="-1" role="dialog" id="coba">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Data Pesan Supplier</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                <form method="post" action="<?php echo e(url('/pesan-supplier-store')); ?>">
                        <?php echo csrf_field(); ?>
                        <label for="nama_supplier">Supplier</label>
                        <select name="nama_supplier" id="nama_supplier" class="select2-example">
                        <option value="-" disabled="true" selected="true">Pilih Nama Supplier</option>
                        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($s->ID_SUPPLIER); ?>"><?php echo e($s->NAMA_SUPPLIER); ?> - <?php echo e($s->ALAMAT_SUPPLIER); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                       
                        <label for="Nama" style="margin-top:10px;">Deskripsi</label>
                        <div class="form-group">
                        <textarea class="demo-code-preview form-control mt-1" placeholder="Deskripsi Pesanan" name="deskripsi" id="message-text" value="<?php echo e(old('deskripsi')); ?>"></textarea>
                        </div>

                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Insert</button>
                    </form>
                </div>
                </div>
            </div>
            </div>
             <!-- tutup modal -->
                <table id="myTable" class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                        <th>Status</th>
                        <th>Tanggal</th>
                        <th>Nama Supplier</th>
                        <th>Deskripsi Pesanan</th>
                        <th>Aksi</th>
                        </tr>
                    </thead>
                <tbody>
                    <?php $__currentLoopData = $catatan_order_supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td>
        <form class="post0" method="post" action="<?php echo e(url('/update-status-pesan-supplier')); ?>">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value="<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>">
          <?php if($co->STATUS_ORDER_SUPPLIER == 1): ?>
          <div class="custom-control custom-switch">
          <input type="checkbox" checked class="custom-control-input" id="switch<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>">
          <label class="custom-control-label" for="switch<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>"></label>
          </div>
          <span class="badge badge-success"><font size="1">Selesai</font></span>
            
            <?php else: ?>
          <div class="custom-control custom-switch">
          <input type="checkbox" class="custom-control-input" id="switch<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>">
          <label class="custom-control-label" for="switch<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>"></label>
          </div>
          <span class="badge badge-danger"><font size="1">Belum Selesai</font></span>    
         <?php endif; ?> 
      </form>
                    </td>
                    <td>
                    <?php echo e(date('d-m-Y H:i:s', strtotime($co->TANGGAL_CATATAN_ORDER_SUPPLIER))); ?>

                   
                    </td>
                    <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($s->ID_SUPPLIER==$co->ID_SUPPLIER): ?>
                        <td><?php echo e($s->NAMA_SUPPLIER); ?> - <?php echo e($s->ALAMAT_SUPPLIER); ?></td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($co->DESKRIPSI_CATATAN_ORDER_SUPPLIER); ?></td>           
                    <td>
                             <!-- Button trigger modal -->
                             <button type="button" class="btn btn-outline-info mb-1" data-toggle="modal" data-target="#editModal<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>">
                             <i class="far fa-edit mr-1"></i>Edit
                            </button>

                          
                            <div class="modal fade" id="editModal<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                            <div class="modal-dialog modal-dialog-scrollable" role="document">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="exampleModalLabel">Edit Pesan Supplier</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    
                                <form method="post" action="<?php echo e(url('/pesan-supplier-update')); ?>">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="id" value="<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>">

                                <label for="Kategori">Supplier</label>
                                <select name="nama_supplier" id="nama_supplier"  class="form-control">
                                <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($co->ID_SUPPLIER==$s->ID_SUPPLIER): ?>         
                                <option selected value="<?php echo e($co->ID_SUPPLIER); ?>" required><?php echo e($s->NAMA_SUPPLIER); ?> - <?php echo e($s->ALAMAT_SUPPLIER); ?></option>
                                <?php else: ?>
                                <option value="<?php echo e($s->ID_SUPPLIER); ?>" required><?php echo e($s->NAMA_SUPPLIER); ?> - <?php echo e($s->ALAMAT_SUPPLIER); ?></option>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>

                                <label for="Nama" style="margin-top:10px;">Deskripsi</label>
                                <div class="form-group">
                                <textarea class="demo-code-preview form-control mt-1" placeholder="Deskripsi Pesanan" name="deskripsi" id="message-text" value="<?php echo e($co->DESKRIPSI_CATATAN_ORDER_SUPPLIER); ?>"><?php echo e($co->DESKRIPSI_CATATAN_ORDER_SUPPLIER); ?></textarea>
                                </div>
                           
                                
                                </div>
                                <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Back</button>
                                <button type="submit" class="btn btn-primary">Update</button>
                               
                            </form>
                                </div>
                                </div>
                            </div>
                            </div> 

                            <!-- tutup Button trigger modal edit -->
                            
            <button type="button" class="btn btn-outline-success mb-1 ml-2" data-toggle="modal" data-target="#modalwa<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>">
            <i class="fab fa-whatsapp mr-1"></i>Whatsapp
            </button>
                           
                    <!-- modal wa-->
            <div class="modal fade" id="modalwa<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>" tabindex="-1" role="dialog" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Whataspp</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <i class="ti-close"></i>
                    </button>
                </div>
                <div class="modal-body">
                    <form method="post" action="<?php echo e(url('/data-supplier-send-wa')); ?>">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($co->ID_CATATAN_ORDER_SUPPLIER); ?>">
                    <div class="form-group">
                    <label for="recipient-name" class="col-form-label">Nomor</label>
                    <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($co->ID_SUPPLIER==$s->ID_SUPPLIER): ?> 
                            <input type="text" class="form-control" placeholder="Nomor Whatsapp" name="nomor_whatsapp" id="recipient-name" value="<?php echo e($s->TELP_SUPPLIER); ?>">
                            <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                        
                        
                    </div>
                    <div class="form-group">
                        <label for="message-text" class="col-form-label">Pesan</label>
                        <textarea class="form-control" placeholder="Deskripsi Pesan" name="pesan_whatsapp" id="message-text"><?php echo e($co->DESKRIPSI_CATATAN_ORDER_SUPPLIER); ?></textarea>
                        </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close
                    </button>
                    <button type="submit" class="btn btn-primary">Kirim Pesan</button>
                    </form>
                </div>
                </div>
            </div>
            </div>
                                    
                                    
                    </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$(document).ready(function (){
    $('#myTable').DataTable();
    $('.select2-example').select2();

    const x = document.getElementsByClassName('post0');
    for(let i=0;i<x.length;i++){
    x[i].addEventListener('click',function(){
        x[i].submit();
    });
    }
});
</script>

<script src="../../vendors/select2/js/select2.min.js"></script>
<script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/examples/pages/user-list.js')); ?>"></script>

<?php if(session('insert')): ?>
<script>
swal("Success!","Data Pesanan Supplier Berhasil Di Tambahkan","success");
</script>
<?php endif; ?>

<?php if(session('update')): ?>
<script>
swal("Success!","Data Pesanan Supplier Berhasil Di Update","success");
</script>
<?php endif; ?>

<?php if(session('update_pesan')): ?>
<script>
swal("Success!","Status Pesanan Berhasil Di Update","success");
</script>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/supplier/order_supplier.blade.php ENDPATH**/ ?>