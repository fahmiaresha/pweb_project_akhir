<?php echo e($slot); ?>

<?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>