
<?php $__env->startSection('title','Laporan Penjualan'); ?>
<?php $__env->startSection('head'); ?>
  <!-- Datatable -->
  <link rel="stylesheet" href="<?php echo e(url('vendors/dataTable/datatables.min.css')); ?>" type="text/css">
 <!-- select2 -->
<link rel="stylesheet" href="../../vendors/select2/css/select2.min.css" type="text/css">

<!-- rangepicker -->
<link rel="stylesheet" href="vendors/datepicker/daterangepicker.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header d-md-flex justify-content-between">
        <div>
            <h3>Laporan</h3>
            <nav aria-label="breadcrumb" class="d-flex align-items-start">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Laporan</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Laporan Penjualan</li>
                </ol>
            </nav>
        </div>
    </div>
    

    <div class="card">
        <div class="card-body">
                <form method="post" action="<?php echo e(url('/search-laporan-penjualan')); ?>" id="form_cari">
                    <?php echo csrf_field(); ?>
                    <label for="Nama">Tanggal Nota</label>
                    <input type="text" name="daterangepicker" class="demo-code-preview form-control mt-1" placeholder="Tanggal Nota" name="daterangepicker" id="daterangepicker" value="<?php echo e(old('daterangepicker')); ?>">
                    <p style="color:#e3bcba;" class="mt-2">*Pilih range tanggal laporan</p>

                    <label for="Kategori">Produk</label>
                        <select name="produk" id="produk" class="select2-example ">
                        <option selected="true" value="">All</option>
                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <?php $__currentLoopData = $kategori_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($p->ID_KATEGORI_PRODUK==$kp->ID_KATEGORI_PRODUK): ?>
                            <option value="<?php echo e($p->ID_PRODUK); ?>" required><?php echo e($kp->NAMA_KATEGORI_PRODUK); ?> - <?php echo e($p->NAMA_PRODUK); ?></option>
                            <?php endif; ?>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                    <p style="color:#e3bcba;" class="mt-2">*Kosongkan jika ingin menampilkan keseluruhan</p>
                   
                                       
                        <div class="row">
                            <div class="col-md-12 text-right">
                                <button type="reset"  class="btn btn-danger mr-1 mt-2">Reset</button>
                                <button  type="submit" class="btn btn-primary mt-2">Tampilkan</button>
                            </div>
                        </div>
                </form>
        </div>
    </div>


    <?php if(session('sukses')): ?>
            <?php $x=session('sukses'); ?>
            <?php 
                $fromdate=session('fromDate'); 
                $todate=session('toDate'); 
                $produk_penjualan=session('produk_penjualan');
                $produk=session('product');
                $input_produk=session('input_produk');
                if($input_produk==null){
                    $input_produk='kosong';  
                }
            ?>
    <div class="card">
        <div class="card-body">
    <center>
    <div class="coba mb-5"><strong> <h4>Laporan Penjualan</h4></strong></div>
    </strong>
    </center>
                <div class="form-row">

                <div class="form-group col-md-4">
                        
                <p><strong> Tanggal : </strong>  <?php echo e(date('d-m-Y', strtotime($fromdate))); ?> s/d
                    <?php echo e(date('d-m-Y', strtotime($todate))); ?></p>  
                </div>
                <div class="form-group col-md-8 text-right">
                <a href="/pdf-laporan-penjualan/<?php echo e($fromdate); ?>/<?php echo e($todate); ?>/<?php echo e($input_produk); ?>" target="_blank" class="btn btn-outline-success ml-2"> <i class="fa fa-download mr-2"></i>Laporan</a>
                </div>

                </div>

                <div class="coba" style="margin-top:-15px;">
               
                <p>  <strong> Sort by :   </strong>     
                <?php if($input_produk=='kosong'): ?>
                    All
                <?php else: ?>
                    <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $kategori_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($input_produk==$p->ID_PRODUK): ?>
                                <?php if($p->ID_KATEGORI_PRODUK==$kp->ID_KATEGORI_PRODUK): ?>
                                    <?php echo e($kp->NAMA_KATEGORI_PRODUK); ?> - <?php echo e($p->NAMA_PRODUK); ?> 
                                <?php endif; ?> 
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                 </p> 
                </div>
                
               

            <div class="table-responsive">
            <table id="myTable" class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                        <th>Nota</th>
                        <th>Tanggal</th>
                        <th>Kategori</th>
                        <th>Pelanggan</th>
                        <th>Kasir</th>
                        <th>Total Bayar</th>
                        </tr>
                    </thead>
                <tbody>
                <?php 
                $total_penjualan_umum=0;
                $total_penjualan_reseller=0;
                $total_penjualan_fix=0;
                ?>
                <?php $__currentLoopData = $x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td>NTA-<?php echo e($p->ID_PENJUALAN); ?></td>
                    <td> <?php echo e(date('d-m-Y H:i:s', strtotime($p->TANGGAL_PENJUALAN))); ?></td>           
                    <td>
                        <?php $__currentLoopData = $kategori_pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==$kp->ID_KATEGORI_PELANGGAN): ?>
                        <?php echo e($kp->NAMA_KATEGORI_PELANGGAN); ?>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                    <?php if($p->ID_PELANGGAN==null): ?>
                    Umum
                    <?php else: ?>
                        <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php if($p->ID_PELANGGAN==$pl->ID_PELANGGAN): ?>
                                <?php echo e($pl->NAMA_PELANGGAN); ?> - <?php echo e($pl->ALAMAT_PELANGGAN); ?>

                             <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>  
                    </td>
                    <td>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($u->id== $p->ID_USER): ?>
                            <?php echo e($u->name); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <?php if($input_produk=='kosong'): ?>
                    <td>Rp. <?php echo e(number_format($p->TOTAL_PENJUALAN)); ?></td>
                    <?php else: ?>
                    <td>Rp. <?php echo e(number_format($p->TOTAL_HARGA_PRODUK)); ?></td>
                    <?php endif; ?>
                    </tr>
                        <?php if($input_produk=='kosong'): ?>
                            <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==1): ?>
                                <?php $total_penjualan_reseller += $p->TOTAL_PENJUALAN; ?>
                            <?php endif; ?>
                            <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==2): ?>
                                <?php $total_penjualan_umum += $p->TOTAL_PENJUALAN; ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==1): ?>
                                <?php $total_penjualan_reseller += $p->TOTAL_HARGA_PRODUK; ?>
                            <?php endif; ?>
                            <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==2): ?>
                                <?php $total_penjualan_umum += $p->TOTAL_HARGA_PRODUK; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $total_penjualan_fix=$total_penjualan_reseller + $total_penjualan_umum; ?>
                </tbody>
                    <tr class="alert alert-info" role="alert">
                    <td  colspan="2" style="text-align:left;  border: none;"><strong><i class="fa fa-info-circle mr-2"></i>Penjualan Reseller</strong></td>
                        <td colspan="1" style="text-align:left;  border: none;">Rp. <?php echo e(number_format($total_penjualan_reseller)); ?> </td>
                        <td  colspan="2" style="text-align:left;  border: none;"><strong><i class="fa fa-info-circle mr-2"></i>Penjualan Non-Reseller</strong></td>
                        <td colspan="1" style="text-align:left;  border: none;">Rp. <?php echo e(number_format($total_penjualan_umum)); ?></td>
                    </tr>
                   
                    
                        
                    <tr class="alert alert-success" role="alert">
                    <td colspan="5" style="text-align:left;  border: none;"><strong><i class="ti-check mr-2"></i>Total Penjualan</strong></td>
                     <td colspan="2" style="text-align:left;  border: none;">Rp. <?php echo e(number_format($total_penjualan_fix)); ?> </td>
                    </tr>
                </table>
                </div>
                

                <br>
                <center>
                <div style="height:auto; max-width:100%; cursor:pointer;">
		        <canvas id="myChart"></canvas>
	            </div>
                </center>
              
               
            </div>
            </div>
           
    </div>
    </div>
                

        <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="vendors/charts/chartjs/chart.min.js"></script>
<script src="assets/js/examples/charts/chartjs.js"></script>

<script>
$(document).ready(function (){
    $('#myTable').DataTable({
        "order":[[1,"asc"]]
    });
    $('.select2-example').select2();
    $('input[name="daterangepicker"]').daterangepicker({
    opens: 'left',
    locale: {
      format: 'DD-MM-YYYY'
    },
    // }, function (start, end, label) {
    //     swal("Tanggal yang dipilih", start.format('DD/MM/YYYY') + ' Sampai ' + end.format('DD/MM/YYYY'), "info")
    });
});

                      
</script>

<script src="../../vendors/select2/js/select2.min.js"></script>
<script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/examples/pages/user-list.js')); ?>"></script>
<script src="vendors/datepicker/daterangepicker.js"></script>

<?php if(session('sukses')): ?>
<script>
swal("Success!","Laporan Berhasil Dibuat!","success");
var ctx = document.getElementById("myChart").getContext('2d');
		var myChart = new Chart(ctx, {
			type: 'bar',
			data: {
				    labels: [<?php
                        foreach ($produk_penjualan as $pp) {
                            foreach ($produk as $p){
                                if($pp->ID_PRODUK==$p->ID_PRODUK){
                                    echo " ' ";
                                    echo  $p->NAMA_PRODUK;
                                    echo " ' ";
                                    echo ',';
                                }
                            }
                         }    
                        ?>],
				datasets: [{
					label: 'Produk Terlaris',
					data: [  <?php
                        foreach ($produk_penjualan as $pp) {
                            echo $pp->TOTAL_PRODUK_DIJUAL;
                            echo ',';
                        }       
                        ?>],
					backgroundColor: [
					'rgba(255, 99, 132, 0.2)',
					'rgba(54, 162, 235, 0.2)',
					'rgba(255, 206, 86, 0.2)',
					'rgba(75, 192, 192, 0.2)',
					'rgba(153, 102, 255, 0.2)',
					'rgba(255, 159, 64, 0.2)'
					],
					borderColor: [
					'rgba(255,99,132,1)',
					'rgba(54, 162, 235, 1)',
					'rgba(255, 206, 86, 1)',
					'rgba(75, 192, 192, 1)',
					'rgba(153, 102, 255, 1)',
					'rgba(255, 159, 64, 1)'
					],
					borderWidth: 1
				}]
			},
			options: {
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero:true
						}
					}]
				}
			}
		});
</script>
<?php endif; ?>

<?php if(session('search_kosong')): ?>
<script>
swal("Oops!","Data Tidak Ditemukan!","error");
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/laporan/laporan_penjualan.blade.php ENDPATH**/ ?>