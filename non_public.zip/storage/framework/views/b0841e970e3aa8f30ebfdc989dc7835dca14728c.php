
<?php $__env->startSection('title','Dashboard'); ?>
<?php $__env->startSection('head'); ?>
  <!-- Datatable -->
  <link rel="stylesheet" href="<?php echo e(url('vendors/dataTable/datatables.min.css')); ?>" type="text/css">
 <!-- select2 -->
<link rel="stylesheet" href="../../vendors/select2/css/select2.min.css" type="text/css">

<!-- rangepicker -->
<link rel="stylesheet" href="vendors/datepicker/daterangepicker.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- hitung nota supplier lunas atau belum lunas -->
<?php 
    $status_sudah_dibayar=0;
    $status_belum_dibayar=0;
?>
    <?php $__currentLoopData = $nota_supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($y->STATUS_NOTA_SUPPLIER==1): ?>
            <?php $status_sudah_dibayar += $y->TOTAL_BAYAR_NOTA_SUPPLIER; ?>
        <?php else: ?>
            <?php $status_belum_dibayar += $y->TOTAL_BAYAR_NOTA_SUPPLIER; ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

<!-- hitung laporan penjualan perhari -->    
<?php 
    $total_penjualan_perhari=0;
?>      
    <?php $__currentLoopData = $laporan_penjualan_perhari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php $total_penjualan_perhari += $lpr->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

<!-- hitung laporan penjualan perbulan -->
<?php 
    $total_penjualan_perbulan=0;
?>  
    <?php $__currentLoopData = $laporan_penjualan_perbulan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lprb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php $total_penjualan_perbulan += $lprb->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan pertahun -->
<?php 
    $total_penjualan_pertahun=0;
?>  
    <?php $__currentLoopData = $laporan_penjualan_pertahun; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lprt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        <?php $total_penjualan_pertahun += $lprt->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     

<!-- hitung laporan penjualan bulan januari -->
<?php $total_penjualan_januari=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_januari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_januari += $lpj->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan februari -->
<?php $total_penjualan_februari=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_februari; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_februari += $lpf->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan maret -->
<?php $total_penjualan_maret=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_maret; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_maret += $lpm->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan april -->
<?php $total_penjualan_april=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_april; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_april += $lpa->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan mei -->
<?php $total_penjualan_mei=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_mei; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpm): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_mei += $lpm->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan juni -->
<?php $total_penjualan_juni=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_juni; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_juni += $lpj->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan juli -->
<?php $total_penjualan_juli=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_juli; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpj): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_juli += $lpj->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan agustus -->
<?php $total_penjualan_agustus=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_agustus; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_agustus += $lpa->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan september -->
<?php $total_penjualan_september=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_september; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lps): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_september += $lps->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan oktober -->
<?php $total_penjualan_oktober=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_oktober; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_oktober += $lpo->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan november -->
<?php $total_penjualan_november=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_november; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpn): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_november += $lpn->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<!-- hitung laporan penjualan bulan desember -->
<?php $total_penjualan_desember=0; ?>
    <?php $__currentLoopData = $laporan_penjualan_desember; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lpd): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $total_penjualan_desember += $lpd->TOTAL_PENJUALAN; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              
<div class="page-header d-md-flex justify-content-between">
        <div>
            <h3>Welcome back, <?php echo e(Session::get('nama_user')); ?></h3>
            <?php if(auth()->user()->ID_JABATAN=="1"): ?>
            <p class="text-muted">Halaman ini menunjukkan ringkasan tahunan penjualan dan nota supplier.</p>
            <?php endif; ?>

            <?php if(auth()->user()->ID_JABATAN=="2"): ?>
            <p class="text-muted">Halaman ini menunjukkan ringkasan penjualan produk.</p>
            <?php endif; ?>
        </div>
        <div class="mt-3 mt-md-0">
            <div class="btn btn-outline-light">
                <span> <?php
            date_default_timezone_set('Asia/Jakarta');
            $hariIni = new DateTime();
            echo strftime('%A %d %B %Y, %H:%M', $hariIni->getTimestamp()) . '<br>';
            ?></span>
            </div>
        </div>
</div>

<div class="row">
        <div class="col-md-3">
        <a href="/data-produk">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title"> <?php echo e($total_produk); ?> </h6>
                    </div>
                    <div class="coba" style="margin-top:-10px;">Jumlah Produk</div>
                </div>
            </div>
            </a>
        </div>
        

        <div class="col-md-3">
        <a href="/kategori-produk">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title"> <?php echo e($total_kategori_produk); ?> </h6>
                    </div>
                    <div class="coba" style="margin-top:-10px;">Jumlah Kategori Produk</div>
                </div>
            </div>
        </a>
        </div>

        <div class="col-md-3">
        <a href="/service-pelanggan">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title"> <?php echo e($total_service); ?> </h6>
                    </div>
                    <div class="coba" style="margin-top:-10px;">Jumlah Service</div>
                </div>
            </div>
        </a>
        </div>

        <div class="col-md-3">
        <a href="/data-penjualan">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title"> <?php echo e($total_penjualan); ?> </h6>
                    </div>
                    <div class="coba" style="margin-top:-10px;">Jumlah Transaksi</div>
                </div>
            </div>
        </a>
        </div>
</div>

<!-- hak akses owner -->
<?php if(auth()->user()->ID_JABATAN=="1"): ?>
<div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title mb-2">Penjualan </h6>
                    </div>
                    <div>
                        <div class="list-group list-group-flush">
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h5>Hari</h5>
                                    <div>Total penjualan</div>
                                </div>
                                <h3 class="text-warning mb-0">Rp. <?php echo e(number_format($total_penjualan_perhari)); ?></h3>
                            </div>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h5>Bulan</h5>
                                    <div>Total penjualan</div>
                                </div>
                                <div>
                                    <h3 class="text-info mb-0">Rp. <?php echo e(number_format($total_penjualan_perbulan)); ?></h3>
                                </div>
                            </div>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h5>Tahun</h5>
                                    <div>Total penjualan</div>
                                </div>
                                <div>
                                    <h3 class="text-success mb-0">Rp. <?php echo e(number_format($total_penjualan_pertahun)); ?></h3>
                                </div>
                            </div>
                            <div class="mt-3">
                                    <a href="/pdf-laporan-penjualan/<?php echo e($tgl_awal_laporan_tahunan); ?>/<?php echo e($tgl_akhir_laporan_tahunan); ?>/kosong" target="_blank" class="btn btn-primary pull-right">Report Detail</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title mb-2">Supplier </h6>
                    </div>
                    <div>
                        <div class="list-group list-group-flush">
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h5>Lunas</h5>
                                    <div>Total nota</div>
                                </div>
                                    
                                <h3 class="text-success mb-0">Rp. <?php echo e(number_format($status_sudah_dibayar)); ?></h3>
                            </div>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h5>Belum Lunas</h5>
                                    <div>Total nota</div>
                                </div>
                                <div>
                                    <h3 class="text-danger mb-0">Rp. <?php echo e(number_format($status_belum_dibayar)); ?></h3>
                                </div>
                            </div>
                            <div class="mt-3">
                                    <a href="/pdf-nota-supplier/<?php echo e($tgl_awal_laporan_tahunan); ?>/<?php echo e($tgl_akhir_laporan_tahunan); ?>/kosong" target="_blank" class="btn btn-warning pull-right">Report Detail</a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
</div>
<?php endif; ?>




<!-- hak akses admin -->
<div class="row">
<div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title mb-2">Produk terjual</h6>
                    </div>
                    <div>
                        <div class="list-group list-group-flush">
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h5>Hari</h5>
                                    <div>Total penjualan</div>
                                </div>
                                <h3 class="text-warning mb-0"><?php echo e($produk_terjual_hari); ?></h3>
                            </div>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h5>Bulan</h5>
                                    <div>Total penjualan</div>
                                </div>
                                <div>
                                    <h3 class="text-info mb-0"><?php echo e($produk_terjual_bulanan); ?></h3>
                                </div>
                            </div>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <h5>Tahun</h5>
                                    <div>Total penjualan</div>
                                </div>
                                <div>
                                    <h3 class="text-success mb-0"><?php echo e($produk_terjual_tahunan); ?></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <?php
            $produk = \DB::select("SELECT * from produk where STOK_PRODUK < 10");
            $kategori_produk = \DB::select("SELECT * from kategori_produk");
            $suppier = \DB::select("SELECT * from supplier");
            $catatan_order_supplier = \DB::select("SELECT * from catatan_order_supplier");
        ?>
        <div class="col-md-6">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title mb-2">Supplier</h6>
                    </div>
                    <div>
                        <div class="list-group list-group-flush">
                                <?php
                                $pesanan_selesai=0;
                                $pesanan_blm_selesai=0;
                                ?>
                            <?php $__currentLoopData = $catatan_order_supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($cos->STATUS_ORDER_SUPPLIER==1): ?>
                                    <?php $pesanan_selesai++; ?>
                                <?php else: ?>
                                    <?php $pesanan_blm_selesai++; ?>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <!-- <h5>Hari</h5> -->
                                    <div>Pesanan Selesai</div>
                                </div>
                                <h3 class="text-warning mb-0"><?php echo $pesanan_selesai; ?></h3>
                            </div>

                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <!-- <h5>Bulan</h5> -->
                                    <div>Pesanan Belum Selesai</div>
                                </div>
                                <div>
                                    <h3 class="text-success mb-0"><?php echo $pesanan_blm_selesai; ?></h3>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title mb-2">Stok</h6>
                    </div>
                    <div>
                        <div class="list-group list-group-flush">
                            <div class="list-group-item d-flex justify-content-between align-items-center px-0">
                                <div>
                                    <div>Produk hampir habis</div>
                                    <!-- <div>Total penjualan</div> -->
                                </div>
                                <h3 class="text-danger mb-0"><?php echo e(count($produk)); ?></h3>
                            </div>
                        </div>
                        <div class="mt-3">
                                   <button class="btn btn-primary pull-right" onclick="show_detail()">Detail Produk</button>
                            </div>
                    </div>
                </div>
            </div>

        </div>

       
</div>

<?php if(auth()->user()->ID_JABATAN=="1"): ?>
<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title mb-2">Penjualan</h6>
                    </div>
                    <div style="height:auto; max-width:100%; cursor:pointer;">
                            <canvas id="penjualan"></canvas>
                            </div>
                </div>
            </div>
        </div>
</div>
<?php endif; ?>

<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body">
                    <div class="d-flex justify-content-between">
                        <h6 class="card-title mb-2">Produk</h6>
                    </div>
                    <div style="height:auto; max-width:100%; cursor:pointer;">
                            <canvas id="produk"></canvas>
                            </div>
                </div>
            </div>
        </div>
</div>

<div class="modal fade" id="detail_produk_hampir_habis" tabindex="-1" role="dialog" aria-hidden="true">
      <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title" id="exampleModalCenterTitle">Produk hampir habis</h5>
            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
              <i class="ti-close"></i>
            </button>
          </div>
          <div class="modal-body">
          <table class="table table-active table-hover" id="myTable">
                        <thead>
                        <tr>
                        <center>
                        
                          <th>#</th>
                          <th>Supplier</th>
                          <th>Kategori</th>
                          <th>Produk</th>
                          <th>Stok</th>
                          </center>
                        </tr>
                        </thead>
                        <tr>
                        
                        <?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <td><?php echo e($loop->iteration); ?></td>
                            <?php $__currentLoopData = $suppier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($p->ID_SUPPLIER==$s->ID_SUPPLIER): ?>
                                    <td><?php echo e($s->NAMA_SUPPLIER); ?> - <?php echo e($s->ALAMAT_SUPPLIER); ?></td>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        
                            <?php $__currentLoopData = $kategori_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($p->ID_KATEGORI_PRODUK==$kp->ID_KATEGORI_PRODUK): ?>
                                <td><?php echo e($kp->NAMA_KATEGORI_PRODUK); ?></td>
                                <td><?php echo e($p->NAMA_PRODUK); ?></td>
                                <?php endif; ?>    
                                
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                           
                           
                            <td style="text-align:center;"><?php echo e($p->STOK_PRODUK); ?></td>
                            
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>
                        <br>
          </div>
         
        </div>
      </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    function show_detail(){
        $('#detail_produk_hampir_habis').modal('show');
    }

$(document).ready(function (){
    $('#myTable').DataTable();
});

</script>

<script src="vendors/charts/chartjs/chart.min.js"></script>
<script src="assets/js/examples/charts/chartjs.js"></script>
<script src="../../vendors/select2/js/select2.min.js"></script>
<script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/examples/pages/user-list.js')); ?>"></script>
<script src="vendors/datepicker/daterangepicker.js"></script>

  <!-- Dashboard scripts -->
  <script src="<?php echo e(url('assets/js/examples/pages/dashboard.js')); ?>"></script>

   <!-- Apex chart -->
   <script src="<?php echo e(url('/vendors/charts/apex/apexcharts.min.js')); ?>"></script>

<script>
var ctx = document.getElementById("penjualan").getContext('2d');
		var myChart = new Chart(ctx, {
			type: 'bar',
			data: {
				    labels: ["Januari", "Febuari" , "Maret" , "April" , "Mei" , "Juni" , "Juli" , "Agustus" , "September" , "Oktober" , "November" , "Desember"],
				datasets: [{
					label: 'Grafik Penjualan',
					data: [
                        <?php echo $total_penjualan_januari; ?>,
                        <?php echo $total_penjualan_februari; ?>,
                        <?php echo $total_penjualan_maret; ?>,
                        <?php echo $total_penjualan_april; ?>,
                        <?php echo $total_penjualan_mei; ?>,
                        <?php echo $total_penjualan_juni; ?>,
                        <?php echo $total_penjualan_juli; ?>,
                        <?php echo $total_penjualan_agustus; ?>,
                        <?php echo $total_penjualan_september; ?>,
                        <?php echo $total_penjualan_oktober; ?>,
                        <?php echo $total_penjualan_november; ?>,
                        <?php echo $total_penjualan_desember; ?>,
                    ],
					backgroundColor: [
					'rgba(255, 99, 132, 0.2)',
					'rgba(54, 162, 235, 0.2)',
					'rgba(255, 206, 86, 0.2)',
					'rgba(75, 192, 192, 0.2)',
					'rgba(153, 102, 255, 0.2)',
					'rgba(255, 159, 64, 0.2)',
                    'rgba(255,0,0,0.2)',
                    'rgba(255,153,51,0.2)',
                    'rgba(0,153,0,0.2)',
                    'rgba(102,51,255,0.2)',
                    'rgba(204,255,153,0.3)',
                    'rgba(153,51,0,0.3)',
					],
					borderColor: [
					'rgba(255,99,132,1)',
					'rgba(54, 162, 235, 1)',
					'rgba(255, 206, 86, 1)',
					'rgba(75, 192, 192, 1)',
					'rgba(153, 102, 255, 1)',
					'rgba(255, 159, 64, 1)',
                    'rgba(255,0,0,1)',
                    'rgba(255,153,51,1)',
                    'rgba(0,153,0,1)',
                    'rgba(102,51,255,1)',
                    'rgba(204,255,153,1)',
                    'rgba(153,51,0,1)',
					],
					borderWidth: 1
				}]
			},
			options: {
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero:true
						}
					}]
				}
			}
		});
</script>

<script>
var produk = document.getElementById("produk").getContext('2d');
		var myChart = new Chart(produk, {
			type: 'bar',
			data: {
				    labels: [<?php
                        foreach ($produk_penjualan as $pp) {
                            foreach ($produk as $p){
                                if($pp->ID_PRODUK==$p->ID_PRODUK){
                                    echo " ' ";
                                    echo  $p->NAMA_PRODUK;
                                    echo " ' ";
                                    echo ',';
                                }
                            }
                         }    
                        ?>],
				datasets: [{
					label: 'Grafik Produk Terlaris',
					data: [ <?php
                        foreach ($produk_penjualan as $pp) {
                            echo $pp->TOTAL_PRODUK_DIJUAL;
                            echo ',';
                        }       
                        ?>],
					backgroundColor: [
					'rgba(255, 99, 132, 0.2)',
					'rgba(54, 162, 235, 0.2)',
					'rgba(255, 206, 86, 0.2)',
					'rgba(75, 192, 192, 0.2)',
					'rgba(153, 102, 255, 0.2)',
					'rgba(255, 159, 64, 0.2)',
                    'rgba(255,0,0,0.2)',
                    'rgba(255,153,51,0.2)',
                    'rgba(0,153,0,0.2)',
                    'rgba(102,51,255,0.2)',
                    'rgba(204,255,153,0.3)',
                    'rgba(153,51,0,0.3)',
					],
					borderColor: [
					'rgba(255,99,132,1)',
					'rgba(54, 162, 235, 1)',
					'rgba(255, 206, 86, 1)',
					'rgba(75, 192, 192, 1)',
					'rgba(153, 102, 255, 1)',
					'rgba(255, 159, 64, 1)',
                    'rgba(255,0,0,1)',
                    'rgba(255,153,51,1)',
                    'rgba(0,153,0,1)',
                    'rgba(102,51,255,1)',
                    'rgba(204,255,153,1)',
                    'rgba(153,51,0,1)',
					],
					borderWidth: 1
				}]
			},
			options: {
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero:true
						}
					}]
				}
			}
		});
</script>
<?php
  $x=Session::get('status_toast');
?>
<?php if($x==0): ?>
<script>
toastr.options = {
        timeOut: 3000,
        progressBar: true,
        showMethod: "slideDown",
        hideMethod: "slideUp",
        showDuration: 200,
        hideDuration: 200
    };
toastr.success('Welcome !');
</script>
<?php Session::put('status_toast','1'); ?>
<?php endif; ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/dashboard2.blade.php ENDPATH**/ ?>