<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Laporan Penjualan Barang <?php echo e(date('d-m-Y', strtotime($fromdate))); ?> - <?php echo e(date('d-m-Y', strtotime($todate))); ?></title>
</head>
<style>
 @page  {
    size: 21cm 29.7cm;
 }
 body {font-size: 11pt;
    }
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #403b3b;
  color: white;
}
    </style>
<body>
<?php
    date_default_timezone_set('Asia/Jakarta');
?>
<strong><p style="text-align:right;">Dibuat : <?php echo e(date('d-m-Y H:i:s')); ?></p> </strong>
    

    <center>
    <strong>
    <div class="coba" style="margin-bottom:5px;"><font size="5"><strong>Toko Bagus</strong></font>
    
    </div>
    <div class="coba" style="margin-bottom:5px;"><font size="5"><strong>Laporan Penjualan Barang</strong></font></div>
    </strong>
    </center>
    <strong><p>Tanggal Laporan :   <?php echo e(date('d-m-Y', strtotime($fromdate))); ?> s/d
               <?php echo e(date('d-m-Y', strtotime($todate))); ?></p> </strong> 
    
               <p style="margin-top:-10px;"> <strong> Sort by :    
                <?php if($input_produk=='kosong'): ?>
                    All
                <?php else: ?>
                    <?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php $__currentLoopData = $kategori_produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($input_produk==$p->ID_PRODUK): ?>
                                <?php if($p->ID_KATEGORI_PRODUK==$kp->ID_KATEGORI_PRODUK): ?>
                                    <?php echo e($kp->NAMA_KATEGORI_PRODUK); ?> - <?php echo e($p->NAMA_PRODUK); ?> 
                                <?php endif; ?> 
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>     
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                </strong> 
                 </p>     
    
    <table style="width:100%;" id="customers">
                        <thead>
                        
                        <tr>
                            <th>#</th>
                            <th><center>Nota</center></th>
                            <th><center>Tanggal</center></th>
                            <th><center>Kategori</center></th>
                            <th><center>Pelanggan</center></th>
                            <th><center>Kasir</center></th>
                            <th><center>Total Bayar</center></th>
                            </tr>
                        </thead>                       
                         
                           
                           <?php 
                            $total_penjualan_umum=0;
                            $total_penjualan_reseller=0;
                            $total_penjualan_fix=0;
                            $nomor=1;
                            ?>
                           <?php $__currentLoopData = $result; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <tr>
                           <td><?php echo e($nomor++); ?></td>
                           <td>NTA-<?php echo e($p->ID_PENJUALAN); ?></td>
                    <td> <?php echo e(date('d-m-Y H:i:s', strtotime($p->TANGGAL_PENJUALAN))); ?></td>           
                    <td>
                        <?php $__currentLoopData = $kategori_pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==$kp->ID_KATEGORI_PELANGGAN): ?>
                        <?php echo e($kp->NAMA_KATEGORI_PELANGGAN); ?>

                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <td>
                    <?php if($p->ID_PELANGGAN==null): ?>
                    Umum
                    <?php else: ?>
                        <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pl): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <?php if($p->ID_PELANGGAN==$pl->ID_PELANGGAN): ?>
                                <?php echo e($pl->NAMA_PELANGGAN); ?> - <?php echo e($pl->ALAMAT_PELANGGAN); ?>

                             <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>  
                    </td>
                    <td>
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($u->id== $p->ID_USER): ?>
                            <?php echo e($u->name); ?>

                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </td>
                    <?php if($input_produk=='kosong'): ?>
                    <td>Rp. <?php echo e(number_format($p->TOTAL_PENJUALAN)); ?></td>
                    <?php else: ?>
                    <td>Rp. <?php echo e(number_format($p->TOTAL_HARGA_PRODUK)); ?></td>
                    <?php endif; ?>
                    </tr>
                        <?php if($input_produk=='kosong'): ?>
                            <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==1): ?>
                                <?php $total_penjualan_reseller += $p->TOTAL_PENJUALAN; ?>
                            <?php endif; ?>
                            <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==2): ?>
                                <?php $total_penjualan_umum += $p->TOTAL_PENJUALAN; ?>
                            <?php endif; ?>
                        <?php else: ?>
                            <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==1): ?>
                                <?php $total_penjualan_reseller += $p->TOTAL_HARGA_PRODUK; ?>
                            <?php endif; ?>
                            <?php if($p->KATEGORI_PELANGGAN_PENJUALAN==2): ?>
                                <?php $total_penjualan_umum += $p->TOTAL_HARGA_PRODUK; ?>
                            <?php endif; ?>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    <?php $total_penjualan_fix=$total_penjualan_reseller + $total_penjualan_umum; ?>
                                 
                    <tfoot>
                    <tr>
                    <td  colspan="3" style="text-align:left;  border: none;"><strong><i class="fa fa-info-circle mr-2"></i>Penjualan Reseller</strong></td>
                        <td colspan="1" style="text-align:left;  border: none;">Rp. <?php echo e(number_format($total_penjualan_reseller)); ?> </td>
                        <td  colspan="2" style="text-align:left;  border: none;"><strong><i class="fa fa-info-circle mr-2"></i>Penjualan Non-Reseller</strong></td>
                        <td colspan="1" style="text-align:left;  border: none;">Rp. <?php echo e(number_format($total_penjualan_umum)); ?></td>
                    </tr>
                   
                    
                        
                    <tr style="background-color:#009DC4; color:white">
                        <td colspan="5" style="text-align:left;  border: none;"><strong><i class="ti-check mr-2"></i>Total Penjualan</strong></td>
                        <td colspan="2" style="text-align:right;  border: none;">Rp. <?php echo e(number_format($total_penjualan_fix)); ?> </td>
                    </tr>
                    </tfoot>
                </table>
    <br>

           
               <center>
               <div class="yay">© <?php echo e(date('Y')); ?> - Toko Bagus . All rights reserved</div>
               </center>

               
              
              
</body>
</html><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/laporan/pdf_penjualan.blade.php ENDPATH**/ ?>