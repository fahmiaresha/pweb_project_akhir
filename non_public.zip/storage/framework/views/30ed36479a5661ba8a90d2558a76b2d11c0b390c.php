<?php $__env->startSection('head'); ?>
    <!-- Datepicker -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/datepicker/daterangepicker.css')); ?>">

    <!-- Prism -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/prism/prism.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <div>
            <h3>Datepicker</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Forms</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Datepicker</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-body">
                            <p class="lead">
                                A JavaScript component for choosing date ranges, dates and times. <a
                                    href="http://www.daterangepicker.com/" class="link-1" target="_blank">Plugin
                                    page</a>.
                            </p>
                            <div data-label="INCLUDED FILES" class="demo-code-preview">
                                <pre><code class="language-html">&lt;!-- Css --&gt;
&lt;link rel="stylesheet" href="vendors/datepicker/daterangepicker.css" type="text/css"&gt;

&lt;!-- Javascript --&gt;
&lt;script src="vendors/datepicker/daterangepicker.js"&gt;&lt;/script&gt;</code></pre>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Single Date Picker</h6>
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" name="single-date-picker" class="form-control">
                                </div>
                            </div>
                            <div data-label="HTML" class="demo-code-preview">
                                <pre><code class="language-html">&lt;input type="text" name="daterangepicker" class="form-control"&gt;</code></pre>
                            </div>
                            <div data-label="JS" class="demo-code-preview">
                                <pre><code class="language-js">$('input[name="daterangepicker"]').daterangepicker({
  singleDatePicker: true,
  showDropdowns: true
});</code></pre>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Simple Date Range Picker</h6>
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" name="simple-date-range-picker" class="form-control">
                                </div>
                            </div>
                            <div data-label="HTML" class="demo-code-preview">
                                <pre><code class="language-html">&lt;input type="text" name="daterangepicker" class="form-control"&gt;</code></pre>
                            </div>
                            <div data-label="JS" class="demo-code-preview">
                                <pre><code
                                        class="language-js">$('input[name="daterangepicker"]').daterangepicker();</code></pre>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Simple Date Range Picker With a Callback</h6>
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" name="simple-date-range-picker-callback" class="form-control">
                                </div>
                            </div>
                            <div data-label="HTML" class="demo-code-preview">
                                <pre><code class="language-html">&lt;input type="text" name="daterangepicker" class="form-control"&gt;</code></pre>
                            </div>
                            <div data-label="JS" class="demo-code-preview">
                                        <pre><code class="language-js">$('input[name="daterangepicker"]').daterangepicker({
    opens: 'left'
}, function (start, end, label) {
    swal("A new date selection was made", start.format('YYYY-MM-DD') + ' to ' + end.format('YYYY-MM-DD'), "success")
});</code></pre>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Date Range Picker With Times</h6>
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" name="datetimes" class="form-control">
                                </div>
                            </div>
                            <div data-label="HTML" class="demo-code-preview">
                                <pre><code class="language-html">&lt;input type="text" name="datetimes" class="form-control"&gt;</code></pre>
                            </div>
                            <div data-label="JS" class="demo-code-preview">
                                <pre><code class="language-js">$('input[name="datetimes"]').daterangepicker({
    timePicker: true,
    startDate: moment().startOf('hour'),
    endDate: moment().startOf('hour').add(32, 'hour'),
    locale: {
        format: 'M/DD hh:mm A'
    }
});</code></pre>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <h6 class="card-title">Input Initially Empty</h6>
                            <div class="row">
                                <div class="col-md-8">
                                    <input type="text" name="datefilter" class="form-control">
                                </div>
                            </div>
                            <div data-label="HTML" class="demo-code-preview">
                                <pre><code class="language-html">&lt;input type="text" name="datefilter" class="form-control"&gt;</code></pre>
                            </div>
                            <div data-label="JS" class="demo-code-preview">
                                <pre><code class="language-js">var datefilter = $('input[name="datefilter"]');
datefilter.daterangepicker({
    autoUpdateInput: false,
    locale: {
        cancelLabel: 'Clear'
    }
});

datefilter.on('apply.daterangepicker', function(ev, picker) {
    $(this).val(picker.startDate.format('MM/DD/YYYY') + ' - ' + picker.endDate.format('MM/DD/YYYY'));
});

$('input.create-event-datepicker').daterangepicker({
    singleDatePicker: true,
    showDropdowns: true,
    autoUpdateInput: false
}).on('apply.daterangepicker', function(ev, picker) {
    $(this).val(picker.startDate.format('MM/DD/YYYY'));
});</code></pre>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Datepicker -->
    <script src="<?php echo e(url('vendors/datepicker/daterangepicker.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/examples/datepicker.js')); ?>"></script>

    <!-- Prism -->
    <script src="<?php echo e(url('vendors/prism/prism.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\themeforest\gogi\resources\views/datepicker.blade.php ENDPATH**/ ?>