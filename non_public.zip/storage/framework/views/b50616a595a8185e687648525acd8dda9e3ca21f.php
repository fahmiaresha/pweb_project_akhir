
<?php $__env->startSection('title','Data Whatsapp'); ?>
<?php $__env->startSection('head'); ?>
  <!-- Datatable -->
  <link rel="stylesheet" href="<?php echo e(url('vendors/dataTable/datatables.min.css')); ?>" type="text/css">
 <!-- select2 -->
<link rel="stylesheet" href="../../vendors/select2/css/select2.min.css" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>



<div class="page-header d-md-flex justify-content-between">
        <div>
            <h3>Whatsapp</h3>
            <nav aria-label="breadcrumb" class="d-flex align-items-start">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <!-- <li class="breadcrumb-item">
                        <a href="#">Pelanggan</a>
                    </li> -->
                    <li class="breadcrumb-item active" aria-current="page">Data Whatsapp</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
            <!-- modal -->
            <button type="button" class="btn btn-primary mb-3" data-toggle="modal"  data-target="#coba">
            <i class="fa fa-plus-circle mr-2"></i>Pesan Whatsapp</button>
            <div class="modal fade" tabindex="-1" role="dialog" id="coba">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Whatsapp</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                <form method="post" action="<?php echo e(url('/whatsapp-store')); ?>">
                        <?php echo csrf_field(); ?>
                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Kategori</label>
                        <input type="text" class="form-control" placeholder="Kategori Whatsapp" name="kategori" id="recipient-name" required>
                    </div>

                    <div class="form-group">
                        <label for="recipient-name" class="col-form-label">Nomor</label>
                        <input type="text" class="form-control" placeholder="Nomor Whatsapp" name="nomor_whatsapp" id="recipient-name"required>
                    </div>

                    <div class="form-group">
                        <label for="message-text" class="col-form-label">Pesan</label>
                        <textarea class="form-control" placeholder="Deskripsi Pesan" name="pesan_whatsapp" id="message-text" required></textarea>
                    </div>  

          
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Insert</button>
                    </form>
                </div>
                </div>
            </div>
            </div>
             <!-- tutup modal -->
                <table id="myTable" class="table table-striped table-bordered table-hover ">
                    <thead>
                        <tr>
                        <!-- <th>No</th> -->
                        <th>Tanggal</th>
                        <th>Kategori</th>
                        <th>Nomor</th>
                        <th>Pesan</th>
                        </tr>
                    </thead>
                <tbody>
                    <?php $__currentLoopData = $whatsapp; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $w): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                    <td><?php echo e(date('d-m-Y H:i:s', strtotime($w->TANGGAL_WHATSAPP))); ?></td>
                    <td><?php echo e($w->KATEGORI_WHATSAPP); ?></td>           
                    <td><?php echo e($w->NO_WHATSAPP); ?></td>
                    <td><?php echo e($w->PESAN_WHATSAPP); ?></td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
                </table>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$(document).ready(function (){
    $('#myTable').DataTable();
    $('.select2-example').select2();
});


</script>
</script>

<script src="../../vendors/select2/js/select2.min.js"></script>
<script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/examples/pages/user-list.js')); ?>"></script>

<?php if(session('insert')): ?>
<script>
swal("Success!","Data Whatsapp Berhasil Di Tambahkan","success");
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/whatsapp.blade.php ENDPATH**/ ?>