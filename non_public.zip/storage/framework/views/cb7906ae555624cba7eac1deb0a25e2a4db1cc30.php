


<?php $__env->startSection('title','Nota Service'); ?>
<?php $__env->startSection('head'); ?>
  <!-- Datatable -->
  <link rel="stylesheet" href="<?php echo e(url('vendors/dataTable/datatables.min.css')); ?>" type="text/css">
 <!-- select2 -->
<link rel="stylesheet" href="../../vendors/select2/css/select2.min.css" type="text/css">
<?php $__env->stopSection(); ?>


<?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($id_nota==$s->ID_SERVICE): ?>
    <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php if($s->ID_PELANGGAN==$p->ID_PELANGGAN): ?>
<?php $__env->startSection('content'); ?>
<div class="row">
        <div class="col-md-12">
            <div class="card">
                <div class="card-body p-50">
                    <div class="invoice">
                        <div class="d-md-flex justify-content-between align-items-center">
                            <h2 class="font-weight-bold d-flex align-items-center">
                            <img class="logo" src="<?php echo e(url('assets/media/image/logo.png')); ?>" alt="logo">
                            </h2>
                            <h4 class="text-xs-left m-b-0">Service #SRV-<?php echo e($id_nota); ?></h3>
                        </div>
                        <hr class="m-t-b-50">
                        <div class="row">
                            <div class="col-md-6">
                                <p>
                                    <b>Toko Bagus</b>
                                </p>
                                <p>97,<br>Wonocolo,<br>Sepanjang Sidoarjo 61257</p>
                            </div>
                            
                            <div class="col-md-6">
                                <p class="text-right">
                                    <b>Invoice to</b>
                                </p>
                                                           
                                <p class="text-right"><?php echo e($p->NAMA_PELANGGAN); ?>,<br><?php echo e($p->ALAMAT_PELANGGAN); ?>,<br><?php echo e($p->TELP_PELANGGAN); ?>.
                                </p>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                
                            </div>
                        </div>
                        
                        <?php if($id_nota==$s->ID_SERVICE): ?>
                        <div class="table-responsive"> 
                            <table class="table mb-4 mt-4">
                                <thead class="thead-light">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Sepeda</th>
                                    <th>Deskripsi</th>
                                </tr>
                                </thead>
                                <tbody>
                               
                                <tr class="text-right">
                                    <td class="text-left"><font size="2"><?php echo e($s->TANGGAL_SERVICE); ?></font></td>
                                    <td class="text-left"><font size="2"><?php echo e($s->NAMA_SEPEDA_SERVICE); ?></font></td>
                                    <td class="text-left"><font size="2"><?php echo e($s->DESKRIPSI_SERVICE); ?></font></td>
                                </tr>
                                </tbody>
                               
                               
                            </table>
                            
                        </div>
                      
                        <p class="text-center small text-muted  m-t-50">
                        <span class="row">
                        <br>
                        <br>
                            <span class="col-md-6 offset-3">
                                © <?php echo e(date('Y')); ?> - Toko Bagus . All rights reserved
                            </span>
                        </span>
                        </p>
                    </div>
                    <div class="text-right d-print-none">
                        <hr class="my-5">
                        <a href="javascript:window.print()" class="btn btn-success ml-2" style="margin-top:-20px;"> <i class="fa fa-print mr-1"></i>Print Nota</a>
                         <!-- <a href="#" class="btn btn-primary">Send Invoice</a> -->
                    </div>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>

<script>
$(document).ready(function (){
    $('#myTable').DataTable();
    $('.select2-example').select2();
});
</script>

<script src="../../vendors/select2/js/select2.min.js"></script>
<script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/examples/pages/user-list.js')); ?>"></script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/pelanggan/nota_service.blade.php ENDPATH**/ ?>