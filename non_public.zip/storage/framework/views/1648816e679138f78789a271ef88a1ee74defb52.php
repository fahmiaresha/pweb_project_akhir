
<?php $__env->startSection('title','Data Pelanggan'); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/pelanggan/pelanggan.blade.php ENDPATH**/ ?>