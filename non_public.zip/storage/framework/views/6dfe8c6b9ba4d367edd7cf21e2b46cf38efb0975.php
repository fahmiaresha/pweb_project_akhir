<?php $__env->startSection('head'); ?>
    <!-- Morsis -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/charts/morsis/morris.css')); ?>" type="text/css">

    <!-- Prism -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/prism/prism.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <div>
            <h3>Morsis</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Charts</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Morsis</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-body">
                            <p class="lead">
                                Morsis is a popular open source library that helps us to plot data in web applications.
                                <a href="https://morrisjs.github.io/morris.js/" class="link-1" target="_blank">Plugin
                                    page</a>.
                            </p>
                            <div data-label="INCLUDED FILES" class="demo-code-preview">
                                <pre><code class="language-html">&lt;!-- Style --&gt;
&lt;link rel="stylesheet" href="vendors/charts/morsis/morris.css" type="text/css"&gt;

&lt;script src="vendors/charts/morsis/raphael-2.1.4.min.js"&gt;&lt;/script&gt;
&lt;script src="vendors/charts/morsis/morris.min.js"&gt;&lt;/script&gt;</code></pre>
                            </div>
                            <p>We prepared demo samples. You don't have to use them. You can create your own demos.</p>
                            <div data-label="INCLUDED FILES" class="demo-code-preview">
                                <pre><code class="language-html">&lt;script src="assets/js/examples/charts/morsis.js"&gt;&lt;/script&gt;</code></pre>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="bar-chart" style="height: 250px;"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="line-chart" style="height: 250px;"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="stacked" style="height: 250px;"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="area-chart" style="height: 250px;"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="pie-chart" style="height: 250px;"></div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Morsis -->
    <script src="<?php echo e(url('vendors/charts/morsis/raphael-2.1.4.min.js')); ?>"></script>
    <script src="<?php echo e(url('vendors/charts/morsis/morris.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/examples/charts/morsis.js')); ?>"></script>

    <!-- Prism -->
    <script src="<?php echo e(url('vendors/prism/prism.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\themeforest\gogi\resources\views/morsis.blade.php ENDPATH**/ ?>