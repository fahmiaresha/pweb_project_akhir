
<?php $__env->startSection('title','Laporan Nota Supplier'); ?>
<?php $__env->startSection('head'); ?>
  <!-- Datatable -->
  <link rel="stylesheet" href="<?php echo e(url('vendors/dataTable/datatables.min.css')); ?>" type="text/css">
 <!-- select2 -->
<link rel="stylesheet" href="../../vendors/select2/css/select2.min.css" type="text/css">

<!-- rangepicker -->
<link rel="stylesheet" href="vendors/datepicker/daterangepicker.css" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="page-header d-md-flex justify-content-between">
        <div>
            <h3>Laporan</h3>
            <nav aria-label="breadcrumb" class="d-flex align-items-start">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Laporan</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Laporan Nota Supplier</li>
                </ol>
            </nav>
        </div>
    </div>
    

    <div class="card">
        <div class="card-body">
                <form method="post" action="<?php echo e(url('/search-nota-supplier')); ?>" id="form_cari">
                    <?php echo csrf_field(); ?>
                    <label for="Nama">Tanggal Nota</label>
                    <input type="text" name="daterangepicker" class="demo-code-preview form-control mt-1" placeholder="Tanggal Nota" name="daterangepicker" id="daterangepicker" value="<?php echo e(old('daterangepicker')); ?>">
                    <p style="color:#e3bcba;" class="mt-2">*Pilih range tanggal laporan</p>

                    <label for="Kategori">Supplier</label>
                        <select name="supplier" id="supplier" class="select2-example">
                        <option selected="true" value="">All</option>
                        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($sp->ID_SUPPLIER); ?>" required><?php echo e($sp->NAMA_SUPPLIER); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </select>
                       <p style="color:#e3bcba;" class="mt-2">*Kosongkan jika ingin menampilkan keseluruhan</p>
                   
                                       
                        <div class="row">
                            <div class="col-md-12 text-right">
                                <button type="reset"  class="btn btn-danger mr-1 mt-2">Reset</button>
                                <button  type="submit" class="btn btn-primary mt-2">Tampilkan</button>
                            </div>
                        </div>
                    

                </form>
               
        </div>
    </div>
        <?php if(session('sukses')): ?>
            <?php $x=session('sukses'); ?>
            <?php 
                $fromdate=session('fromDate'); 
                $todate=session('toDate'); 
                $input_supplier=session('input_supplier');
                if($input_supplier==null){
                    $input_supplier='kosong';  
                }
            ?>
    <div class="card">
        <div class="card-body">
    <center>
    <div class="coba mb-5"><strong> <h4>Laporan Nota Supplier</h4></strong></div>
    </strong>
    </center>

    

    

                <div class="form-row">

                <div class="form-group col-md-4">
                        
                <p><strong> Tanggal : </strong>  <?php echo e(date('d-m-Y', strtotime($fromdate))); ?> s/d
                    <?php echo e(date('d-m-Y', strtotime($todate))); ?></p>  
                </div>
                <div class="form-group col-md-8 text-right">
                <a href="/pdf-nota-supplier/<?php echo e($fromdate); ?>/<?php echo e($todate); ?>/<?php echo e($input_supplier); ?>" target="_blank" class="btn btn-outline-success ml-2"> <i class="fa fa-download mr-2"></i>Laporan</a>
                </div>

                </div>

                <div class="coba" style="margin-top:-15px;">
               
                <p>  <strong> Sort by :   </strong>     
                <?php if($input_supplier=='kosong'): ?>
                    All
                <?php else: ?>
                    <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($s->ID_SUPPLIER==$input_supplier): ?>
                                <?php echo e($s->NAMA_SUPPLIER); ?> - <?php echo e($s->ALAMAT_SUPPLIER); ?>

                            <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
                 </p> 
                </div>
                
               

            <div class="table-responsive">
            <table id="myTable" class="table table-striped table-bordered table-hover">
                    <thead>
                        <tr>
                      
                        <th>Supplier</th>
                        <th>Status</th>
                        <th>Nomor Nota</th> 
                        <th>Tanggal Nota</th>
                        <th>Total Bayar</th>
                        </tr>
                    </thead>
                <tbody>
            <?php 
            $status_sudah_dibayar=0;
            $status_belum_dibayar=0;
            ?>
                <?php $__currentLoopData = $x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $y): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                        <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($s->ID_SUPPLIER==$y->ID_SUPPLIER): ?>
                        <td> <?php echo e($s->NAMA_SUPPLIER); ?> - <?php echo e($s->ALAMAT_SUPPLIER); ?></td>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                        <td>
                        <?php if($y->STATUS_NOTA_SUPPLIER==1): ?>
                         Lunas
                        <?php else: ?>
                         Belum Lunas
                        <?php endif; ?>
                        </td>
                        <td> <?php echo e($y->NOMOR_NOTA_SUPPLIER); ?>  </td>
                        
                        <td>  <?php echo e(date('d-m-Y', strtotime($y->TANGGAL_NOTA_DATANG))); ?>  </td>
                   
                        <td> Rp. <?php echo e(number_format($y->TOTAL_BAYAR_NOTA_SUPPLIER)); ?>    </td>
                        </tr>
                    <?php if($y->STATUS_NOTA_SUPPLIER==1): ?>
                        <?php $status_sudah_dibayar += $y->TOTAL_BAYAR_NOTA_SUPPLIER ?>
                    <?php else: ?>
                        <?php $status_belum_dibayar += $y->TOTAL_BAYAR_NOTA_SUPPLIER ?>
                    <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       
                </tbody>
               
                         <tr>
                         <td  colspan="1" class="alert alert-danger" style="text-align:left; border: none;"><strong><i class="ti-alert mr-2"></i>Nota Belum Lunas</strong></td>
                            <td  colspan="2" class="alert alert-danger" style="text-align:right; border: none;">Rp. <?php echo e(number_format($status_belum_dibayar)); ?> </td>

                            <td colspan="1"class="alert alert-success" style="text-align:left; border: none;"><strong><i class="ti-check mr-2"></i>Nota Lunas</strong></td>
                            <td  colspan="2" class="alert alert-success" style="text-align:right; border: none;">Rp. <?php echo e(number_format($status_sudah_dibayar)); ?> </td>        
                        </tr> 
                </table>
                </div>
                
                <br>
                <center>
                <div style="height:auto; max-width:100%; cursor:pointer;">
		        <canvas id="myChart"></canvas>
	            </div>
                </center>
              
                <!-- <?php $id_supp=0; ?>
                <?php $__currentLoopData = $supplier; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $x; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ns): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($id_supp!=$ns->ID_SUPPLIER): ?>
                                        <?php $lunas=0; $blm_lunas=0; ?>
                                    <?php else: ?>
                                        <?php if($id_supp!=0): ?>
                                            <?php echo $lunas; ?>
                                            <?php echo $blm_lunas; ?>
                                        <?php endif; ?>
                                    <?php endif; ?>

                                    <?php if($s->ID_SUPPLIER==$ns->ID_SUPPLIER): ?>
                                            <?php if($ns->STATUS_NOTA_SUPPLIER==1): ?>
                                                    <?php $lunas = $lunas + $ns->TOTAL_BAYAR_NOTA_SUPPLIER; ?>
                                            <?php else: ?>
                                                    <?php $blm_lunas = $blm_lunas + $ns->TOTAL_BAYAR_NOTA_SUPPLIER; ?>
                                            <?php endif; ?>
                                        <?php $id_supp=$s->ID_SUPPLIER; ?>
                                    <?php endif; ?> 
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>        
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> -->
            </div>
            </div>
           
    </div>
    </div>
                

        <?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="vendors/charts/chartjs/chart.min.js"></script>
<script src="assets/js/examples/charts/chartjs.js"></script>

<script>
$(document).ready(function (){
    $('#myTable').DataTable(); 
    $('.select2-example').select2();
    $('input[name="daterangepicker"]').daterangepicker({
    opens: 'left',
    locale: {
      format: 'DD-MM-YYYY'
    },
    // }, function (start, end, label) {
    //     swal("Tanggal yang dipilih", start.format('DD/MM/YYYY') + ' Sampai ' + end.format('DD/MM/YYYY'), "info")
    });
});


</script>

<script src="../../vendors/select2/js/select2.min.js"></script>
<script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/examples/pages/user-list.js')); ?>"></script>
<script src="vendors/datepicker/daterangepicker.js"></script>

<?php if(session('sukses')): ?>
<script>
swal("Success!","Laporan Berhasil Dibuat!","success");
var ctx = document.getElementById("myChart").getContext('2d');
		var myChart = new Chart(ctx, {
			type: 'bar',
			data: {
				labels: ["Belum Lunas", "Lunas"],
				datasets: [{
					label: 'Nota Supplier',
					data: [
                        <?php echo $status_belum_dibayar; ?>,
                        <?php echo $status_sudah_dibayar; ?>
                    ],
					backgroundColor: [
					'rgba(255, 99, 132, 0.2)',
					'rgba(54, 162, 235, 0.2)',
					'rgba(255, 206, 86, 0.2)',
					'rgba(75, 192, 192, 0.2)',
					'rgba(153, 102, 255, 0.2)',
					'rgba(255, 159, 64, 0.2)'
					],
					borderColor: [
					'rgba(255,99,132,1)',
					'rgba(54, 162, 235, 1)',
					'rgba(255, 206, 86, 1)',
					'rgba(75, 192, 192, 1)',
					'rgba(153, 102, 255, 1)',
					'rgba(255, 159, 64, 1)'
					],
					borderWidth: 1
				}]
			},
			options: {
				scales: {
					yAxes: [{
						ticks: {
							beginAtZero:true
						}
					}]
				}
			}
		});
</script>
<?php endif; ?>

<?php if(session('search_kosong')): ?>
<script>
swal("Oops!","Data Tidak Ditemukan!","error");
</script>
<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/laporan/laporan_nota_supplier.blade.php ENDPATH**/ ?>