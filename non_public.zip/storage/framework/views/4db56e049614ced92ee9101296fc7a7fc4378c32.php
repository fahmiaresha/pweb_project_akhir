<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Service #SRV-<?php echo e($id_invoice); ?></title>
</head>
<style>
    @page  {
    size: 5.7cm 5cm;
    margin: 8px 8px 8px 8px;
    }
    body {font-size: 4pt;
    }
</style>
<body>
    <center>
    <strong>
    <div class="coba" style="margin-bottom:1px;">Toko Bagus</div>
    <div class="coba" style="margin-bottom:1px;">Wonocolo Sepanjang No.97</div>
    <div class="coba" style="margin-bottom:1px;">Telp. 089-6346-5688</div>
    </strong>
    </center>

    <table>

    <tbody>
    <tr>
    <td><strong>Nomor <strong></td>
    <td>: SRV-<?php echo e($id_invoice); ?></td>
    </tr>
    <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($s->ID_SERVICE==$id_invoice): ?>
        <tr>
        <td><strong>Tanggal <strong></td>
        <td>:  <?php echo e(date('d-m-Y H:i:s', strtotime($s->TANGGAL_SERVICE))); ?></td>
        </tr>
        <tr>
        <td><strong>Kasir<strong></td>
        <td>:
        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($s->PEGAWAI==$u->id): ?>
                            <?php echo e($u->name); ?>

                        <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </td>
        </tr>
            <?php $__currentLoopData = $pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($s->ID_PELANGGAN==$p->ID_PELANGGAN): ?>
                <tr>
                <td><strong>Pelanggan <strong></td>
                <td>:  <?php echo e($p->NAMA_PELANGGAN); ?></td>
                </tr>
                    <?php $__currentLoopData = $kategori_pelanggan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kp): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($p->ID_KATEGORI_PELANGGAN==$kp->ID_KATEGORI_PELANGGAN): ?>             
                            <tr>
                            <td><strong>Kategori <strong></td>
                            <td>: <?php echo e($kp->NAMA_KATEGORI_PELANGGAN); ?></td>
                            </tr>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>     
    </table>

    <div class="coba">==================================================================</div>

    <table style="width:100%;">
                        <thead>
                        <tr>
                          <th>Nama Sepeda</th>
                          <th>Deskripsi Service</th>
                        </tr>
                        </thead>
                        <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($s->ID_SERVICE==$id_invoice): ?>
                            
                            <tr>
                            <td><center><?php echo e($s->NAMA_SEPEDA_SERVICE); ?> </center></td>
                            <td><center> <?php echo e($s->DESKRIPSI_SERVICE); ?></center></td>
                            </tr>
                           
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

                        
    <div class="coba">==================================================================</div>
    <div class="yay" style="font-size: 3pt;"> © <?php echo e(date('Y')); ?> - Toko Bagus . All rights reserved</div>

<center>
    <div class="terimakasih" style="margin-top:10px;">
    <div class="yay" style="margin-bottom:2px;" ><strong>TERIMA KASIH</strong></div>
    <div class="yay">*Pelanggan Wajib membawa nota saat pengambilan sepeda.</div>
    
    </div>
</center>
    
</body>
</html><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/pelanggan/invoice_service.blade.php ENDPATH**/ ?>