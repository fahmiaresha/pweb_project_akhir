<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>