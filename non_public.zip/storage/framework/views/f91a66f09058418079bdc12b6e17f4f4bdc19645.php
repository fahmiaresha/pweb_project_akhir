<?php $__env->startSection('head'); ?>
    <!-- Prism -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/prism/prism.css')); ?>" type="text/css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="page-header">
        <div>
            <h3>Apex Chart</h3>
            <nav aria-label="breadcrumb">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="#">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Charts</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Apex</li>
                </ol>
            </nav>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12">

            <div class="row">
                <div class="col-md-12">

                    <div class="card">
                        <div class="card-body">
                            <p class="lead">
                                ApexCharts is an open-source modern charting library that helps developers to create
                                beautiful and interactive visualizations for web pages. <a
                                    href="https://apexcharts.com/" class="link-1" target="_blank">Plugin page</a>.
                            </p>
                            <div data-label="INCLUDED FILES" class="demo-code-preview">
                                <pre><code class="language-html">&lt;script src="vendors/charts/apex/apexcharts.min.js"&gt;&lt;/script&gt;</code></pre>
                            </div>
                            <p>We prepared demo samples. You don't have to use them. You can create your own demos.</p>
                            <div data-label="INCLUDED FILES" class="demo-code-preview">
                                <pre><code class="language-html">&lt;script src="assets/js/examples/charts/apex.js"&gt;&lt;/script&gt;</code></pre>
                            </div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="apex_chart_one" style="height: 300px"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="apex_chart_two" style="height: 300px"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="apex_chart_three" style="height: 300px"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="apex_chart_four" style="height: 300px"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="apex_chart_five" style="height: 300px"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="apex_chart_six" style="height: 300px"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div id="apex_chart_eight" style="height: 300px"></div>
                        </div>
                    </div>

                    <div class="card">
                        <div class="card-body">
                            <div class="row">
                                <div class="col-md-6">
                                    <div id="apex_chart_seven" style="height: 300px"></div>
                                </div>
                                <div class="col-md-6">
                                    <div id="apex_chart_nine" style="height: 300px"></div>
                                </div>
                            </div>
                        </div>
                    </div>

                </div>
            </div>

        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- Apex Chart -->
    <script src="https://apexcharts.com/samples/assets/irregular-data-series.js"></script>
    <script src="<?php echo e(url('vendors/charts/apex/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(url('assets/js/examples/charts/apex.js')); ?>"></script>

    <!-- Prism -->
    <script src="<?php echo e(url('vendors/prism/prism.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\themeforest\gogi\resources\views/apexchart.blade.php ENDPATH**/ ?>