
<?php $__env->startSection('title','Profile'); ?>
<?php $__env->startSection('head'); ?>
  <!-- Datatable -->
  <link rel="stylesheet" href="<?php echo e(url('vendors/dataTable/datatables.min.css')); ?>" type="text/css">
 <!-- select2 -->
<link rel="stylesheet" href="../../vendors/select2/css/select2.min.css" type="text/css">

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

<!-- <div class="page-header d-md-flex justify-content-between">
        <div>
            <h3>Profile</h3>
            <nav aria-label="breadcrumb" class="d-flex align-items-start">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item">
                        <a href="<?php echo e(url('/')); ?>">Home</a>
                    </li>
                    <li class="breadcrumb-item">
                        <a href="#">Settings</a>
                    </li>
                    <li class="breadcrumb-item active" aria-current="page">Profile</li>
                </ol>
            </nav>
        </div>
    </div> -->

<div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">

                <?php $z=Session::get('id_user') ?>
                <div class="modal fade" tabindex="-1" role="dialog" id="modal_ubah_password">
                <div class="modal-dialog modal-lg" role="document">
                <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Ubah Password</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                    </button>
                </div>
                <div class="modal-body">
                <form method="post" action="<?php echo e(url('/ubah-password-pegawai')); ?>">       
                <?php echo csrf_field(); ?>
                    <input type="hidden" name="id" value="<?php echo e($z); ?>"> <br/>
                            
                    <div class="form-group row" style="margin-top:-40px;" >
                        <label for="current_password" class="col-md-4 col-form-label text-md-left">Current Password</label>

                        <div class="col-md-6 input-group" id="show_hide_password2">
                            <input id="current_password" type="password" placeholder="Current Password" class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="current_password">
                            <div class="input-group-append" style="padding-bottom: 15px;">
                                <span class="input-group-text"><a href=""><i class="fa fa-eye" aria-hidden="true" style="color:white"></i> </a></span>
                                </div>
                            
                            <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><font size="2"><?php echo e($message); ?></font></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                            <div class="form-group row">
                                <label for="password" class="col-md-4 col-form-label text-md-left">New Password</label>
                                <div class="col-md-6 input-group" id="show_hide_password">
                                <input id="password" type="password" placeholder="New Password" class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password" >
                                <div class="input-group-append" style="padding-bottom: 15px;">
                                <span class="input-group-text"><a href=""><i class="fa fa-eye" aria-hidden="true" style="color:white"></i> </a></span>
                                </div>
                               

                                    <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><font size="2"><?php echo e($message); ?> </font></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>


                            <div class="form-group row">
                                <label for="password-confirm" class="col-md-4 col-form-label text-md-left">Confirm Password</label>

                                <div class="col-md-6 input-group"  id="show_hide_password3">
                                    <input id="password-confirm" type="password" placeholder="Confirm Password" class="form-control  <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password_confirmation">
                                    <div class="input-group-append" style="padding-bottom: 15px;">
                                    <span class="input-group-text"><a href=""><i class="fa fa-eye" aria-hidden="true" style="color:white"></i> </a></span>
                                    </div>
                                    <?php $__errorArgs = ['password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><font size="2"><?php echo e($message); ?> </font></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>

                                
                                
                            </div>

                   

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        Update Password
                                    </button>
                                </div>
                            </div>

                        </form>

          
                </div>
                <!-- <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Insert</button>
                    </form>
                </div> -->
                </div>
            </div>
            </div>
             <!-- tutup modal -->

                <?php $__currentLoopData = $pegawai; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($p->id == $z): ?>
                    <div class="card-header">
                    <center><i class="far fa-id-badge fa-2x"></i></center>
                    <center><strong><font size="5" style="font-family: Cambria, Cochin, Georgia, Times, 'Times New Roman', serif;">Profile Users</font></strong></center>   
                    </div>
                    <div class="card-body">
                    <form method="POST" action="/update-profile">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($z); ?>">
                          <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-left">Nama</label>

                        <div class="col-md-6 input-group">
                            <input type="text" name="nama_admin" id="nama_admin" class="form-control <?php $__errorArgs = ['nama_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($p->name); ?>" readonly>
                            <?php $__errorArgs = ['nama_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><font size="2"><?php echo e($message); ?> </font></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-left">Alamat</label>

                        <div class="col-md-6 input-group">
                        <textarea type="text" class="form-control <?php $__errorArgs = ['alamat_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                             rows="3" name="alamat_admin" id="alamat_admin" readonly><?php echo e($p->alamat_user); ?></textarea>
                             <?php $__errorArgs = ['alamat_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><font size="2"><?php echo e($message); ?> </font></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-left">Telepon</label>

                        <div class="col-md-6 input-group">
                            <input  type="number" name="telp_admin" id="telp_admin" class="form-control <?php $__errorArgs = ['telp_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($p->telp_user); ?>" readonly>
                            <?php $__errorArgs = ['telp_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><font size="2"><?php echo e($message); ?> </font></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-left">Email</label>

                        <div class="col-md-6 input-group">
                            <input  type="email" name ="email_admin" id="email_admin" class="form-control <?php $__errorArgs = ['email_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e($p->email); ?>" readonly> 
                            <?php $__errorArgs = ['email_admin'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><font size="2"><?php echo e($message); ?> </font></strong>
                                        </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-left">Jabatan</label>

                        <div class="col-md-6 input-group">
                            <?php $__currentLoopData = $jabatan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($j->ID_JABATAN==$p->ID_JABATAN): ?>
                                <input type="text" class="form-control" value="<?php echo e($j->NAMA_JABATAN); ?>" readonly>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                        </div>
                    </div>

                    <div class="form-group row">
                        <label class="col-md-4 col-form-label text-md-left"></label>
                        <label class="col-md-3 col-form-label text-md-left"></label>

                        <div class="col-md-4 input-group text-md-right ml-4">
                            <a style="cursor:pointer;" data-toggle="modal"  data-target="#modal_ubah_password">Ubah Password</a>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            <div class="form-group row mb-0">
                                <div class="col-md-6 offset-md-4">
                                    <button type="submit" id="tombol" class="btn btn-primary" onclick="edit()">
                                        Edit Profile
                                    </button>
                                </div>
                            </div>

                          
                            </form>
                    </div>
                </div>
            </div>
        </div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script src="../../vendors/select2/js/select2.min.js"></script>
<script src="<?php echo e(url('vendors/dataTable/datatables.min.js')); ?>"></script>
<script src="<?php echo e(url('assets/js/examples/pages/user-list.js')); ?>"></script>

<script>
$("#tombol").click(function(event) { 
                event.preventDefault(); 
    }); 
    


    function edit(){
        document.getElementById("nama_admin").readOnly=false;
        document.getElementById("alamat_admin").readOnly=false;
        document.getElementById("telp_admin").readOnly=false;
        document.getElementById("email_admin").readOnly=false;
         ganti_tombol();

    }

    function ganti_tombol(){
        document.getElementById("tombol").innerHTML='Update Profile';
        $("#tombol").removeClass("btn btn-primary");
        $("#tombol").addClass("btn btn-success update");
        $("#tombol").attr('id','tombol_update');
        $("#tombol_update").attr("onclick","update()");
    }

        function update(){
            $("form").submit();            
    }

</script>

<script>
$(document).ready(function() {
    $("#show_hide_password a").on('click', function(event) {
        event.preventDefault();
        if($('#show_hide_password input').attr("type") == "text"){
            $('#show_hide_password input').attr('type', 'password');
            $('#show_hide_password i').addClass( "fa-eye-slash" );
            $('#show_hide_password i').removeClass( "fa-eye" );
        }else if($('#show_hide_password input').attr("type") == "password"){
            $('#show_hide_password input').attr('type', 'text');
            $('#show_hide_password i').removeClass( "fa-eye-slash" );
            $('#show_hide_password i').addClass( "fa-eye" );
        }
    });

    $("#show_hide_password2 a").on('click', function(event) {
        event.preventDefault();
        if($('#show_hide_password2 input').attr("type") == "text"){
            $('#show_hide_password2 input').attr('type', 'password');
            $('#show_hide_password2 i').addClass( "fa-eye-slash" );
            $('#show_hide_password2 i').removeClass( "fa-eye" );
        }else if($('#show_hide_password2 input').attr("type") == "password"){
            $('#show_hide_password2 input').attr('type', 'text');
            $('#show_hide_password2 i').removeClass( "fa-eye-slash" );
            $('#show_hide_password2 i').addClass( "fa-eye" );
        }
    });

    $("#show_hide_password3 a").on('click', function(event) {
        event.preventDefault();
        if($('#show_hide_password3 input').attr("type") == "text"){
            $('#show_hide_password3 input').attr('type', 'password');
            $('#show_hide_password3 i').addClass( "fa-eye-slash" );
            $('#show_hide_password3 i').removeClass( "fa-eye" );
        }else if($('#show_hide_password3 input').attr("type") == "password"){
            $('#show_hide_password3 input').attr('type', 'text');
            $('#show_hide_password3 i').removeClass( "fa-eye-slash" );
            $('#show_hide_password3 i').addClass( "fa-eye" );
        }
    });

});
</script>

<?php if(session('update_profile')): ?>
<script>
swal("Success!","Profile Berhasil Di Update","success");
</script>
<?php endif; ?>

<?php if(session('password_sukses_diubah')): ?>
<script>
swal("Success!","Password Berhasil Di Ubah","success");
</script>
<?php endif; ?>

<?php if(session('password_baru_lama_sama')): ?>
<script>
swal("Oops!","Password tidak boleh sama","info");
</script>
<?php endif; ?>

<?php if(session('password_konfirmasipassword_tdk_cocok')): ?>
<script>
swal("Oops!","Konfirmasi password tidak cocok","error");
</script>
<?php endif; ?>


<?php if(session('current_password_tidak_cocok')): ?>
<script>
swal("Oops!","Password salah","error");
</script>
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH I:\Data Aplikasi\xampp\htdocs\tugas_akhir\resources\views/settings/profile.blade.php ENDPATH**/ ?>