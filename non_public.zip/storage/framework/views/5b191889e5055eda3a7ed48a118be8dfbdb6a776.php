<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Gogi - Admin and Dashboard Template</title>

    <!-- Favicon -->
    <link rel="shortcut icon" href="<?php echo e(url('assets/media/image/favicon.png')); ?>"/>

    <!-- Plugin styles -->
    <link rel="stylesheet" href="<?php echo e(url('vendors/bundle.css')); ?>" type="text/css">

    <!-- App styles -->
    <link rel="stylesheet" href="<?php echo e(url('assets/css/app.min.css')); ?>" type="text/css">
</head>
<body class="form-membership">

<!-- begin::preloader-->
<div class="preloader">
    <div class="preloader-icon"></div>
</div>
<!-- end::preloader -->

<div class="form-wrapper">

    <!-- logo -->
    <div id="logo">
        <img src="<?php echo e(url('assets/media/image/dark-logo.png')); ?>" alt="image">
    </div>
    <!-- ./ logo -->

    <?php echo $__env->yieldContent('content'); ?>

</div>

<!-- Plugin scripts -->
<script src="<?php echo e(url('vendors/bundle.js')); ?>"></script>

<!-- App scripts -->
<script src="<?php echo e(url('assets/js/app.min.js')); ?>"></script>
</body>
</html>
<?php /**PATH C:\wamp64\www\themeforest\gogi\resources\views/layouts/auth.blade.php ENDPATH**/ ?>