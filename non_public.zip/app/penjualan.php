<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class penjualan extends Model
{
    protected $table='penjualan';
    protected $primaryKey ='ID_PENJUALAN';
    public $timestamps=false;
}
