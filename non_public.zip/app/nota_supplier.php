<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class nota_supplier extends Model
{
    protected $table='nota_supplier';
    protected $primaryKey ='ID_NOTA_SUPPLIER';
    public $timestamps=false;
}
